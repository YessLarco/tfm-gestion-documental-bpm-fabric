"""
Escenario A — Completitud de Trazabilidad (CT)

Por cada PDF del dataset:
  1. Sube el PDF a la VM (lo copia a /tmp/dataset/) y registra pdfPath.
  2. Inicia una instancia del proceso BPMN en Camunda.
  3. Completa la User Task del registrador.
  4. Espera a que el worker procese las Service Tasks.
  5. Completa la User Task del revisor con la decisión asignada por la mezcla:
        - 80% aprobado=true
        - 10% aprobado=false (rechazo revisor)
        - 10% aprobado=true (será rechazado por legal)
  6. Si aprobado por revisor → completa la User Task del legal con decisión asignada.
  7. Si aprobado por legal → completa la User Task del publicador.

Al final consulta a) historia Camunda b) chaincode "ConsultarHistorial"
y calcula CT = (instancias con historial on-chain consistente con su flujo BPMN) / total.

Uso (dentro de la VM, no en Cloud Shell):
    python3 escenario_a.py --dataset /home/azureuser/dataset --reporte ./reporte_A.json

Requisitos: pip install requests
"""

import argparse
import json
import random
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

try:
    import requests
except ImportError:
    print("ERROR: pip install requests")
    raise


# ---------- Configuración por defecto (puedes pasar parámetros por CLI) ----------
DEFAULT_CAMUNDA = "http://localhost:8080/engine-rest"
DEFAULT_USER = "demo"
DEFAULT_PROC_KEY = "Process_GestionDocumental"
PEER_QUERY_BIN = "/home/azureuser/bpm-fabric/fabric/fabric-samples/bin/peer"
FABRIC_CFG = "/home/azureuser/bpm-fabric/fabric/fabric-samples/config"
TEST_NETWORK = "/home/azureuser/bpm-fabric/fabric/fabric-samples/test-network"


def cargar_args():
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", required=True, help="Carpeta con los PDFs sintéticos")
    p.add_argument("--reporte", default="./reporte_A.json")
    p.add_argument("--camunda", default=DEFAULT_CAMUNDA)
    p.add_argument("--user", default=DEFAULT_USER)
    p.add_argument("--password", required=True, help="Password de Camunda (en CLI por seguridad)")
    p.add_argument("--proceso", default=DEFAULT_PROC_KEY)
    p.add_argument("--pdf-dir-vm", default="/tmp/dataset",
                   help="Carpeta dentro de la VM donde el worker leerá los PDFs (pdfPath)")
    p.add_argument("--mezcla", default="80,10,10",
                   help="Porcentajes: aprobado_total, rechazo_revisor, rechazo_legal")
    return p.parse_args()


# ---------- Cliente Camunda mínimo ----------
class CamundaClient:
    def __init__(self, base_url, user, password):
        self.base = base_url
        self.auth = (user, password)
        self.s = requests.Session()
        self.s.auth = self.auth

    def start_instance(self, proceso_key, variables):
        url = f"{self.base}/process-definition/key/{proceso_key}/start"
        r = self.s.post(url, json={"variables": variables}, timeout=30)
        r.raise_for_status()
        return r.json()

    def list_tasks(self, process_instance_id):
        url = f"{self.base}/task"
        r = self.s.get(url, params={"processInstanceId": process_instance_id}, timeout=30)
        r.raise_for_status()
        return r.json()

    def complete_task(self, task_id, variables=None):
        url = f"{self.base}/task/{task_id}/complete"
        r = self.s.post(url, json={"variables": variables or {}}, timeout=30)
        r.raise_for_status()

    def history_instance(self, process_instance_id):
        url = f"{self.base}/history/process-instance/{process_instance_id}"
        r = self.s.get(url, timeout=30)
        r.raise_for_status()
        return r.json()

    def history_activities(self, process_instance_id):
        url = f"{self.base}/history/activity-instance"
        r = self.s.get(url, params={"processInstanceId": process_instance_id}, timeout=30)
        r.raise_for_status()
        return r.json()


# ---------- Espera activa por la siguiente User Task ----------
def esperar_user_task(cliente, process_instance_id, nombre_actividad_esperada, timeout=30):
    inicio = time.time()
    while time.time() - inicio < timeout:
        tasks = cliente.list_tasks(process_instance_id)
        for t in tasks:
            if t.get("taskDefinitionKey") == nombre_actividad_esperada:
                return t["id"]
        time.sleep(1)
    raise TimeoutError(f"No apareció la tarea {nombre_actividad_esperada} en {timeout}s")


def esperar_fin_instancia(cliente, process_instance_id, timeout=60):
    inicio = time.time()
    while time.time() - inicio < timeout:
        h = cliente.history_instance(process_instance_id)
        if h.get("state") == "COMPLETED":
            return h
        time.sleep(1)
    raise TimeoutError(f"Instancia {process_instance_id} no terminó en {timeout}s")


# ---------- Consulta directa al chaincode vía peer CLI ----------
def consultar_chaincode(doc_id):
    """Llama a peer chaincode query como auditor. Devuelve dict con el historial."""
    env = {
        "PATH": f"{TEST_NETWORK}/../bin:/usr/bin:/bin",
        "FABRIC_CFG_PATH": FABRIC_CFG,
        "CORE_PEER_TLS_ENABLED": "true",
        "CORE_PEER_LOCALMSPID": "Org1MSP",
        "CORE_PEER_TLS_ROOTCERT_FILE":
            f"{TEST_NETWORK}/organizations/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt",
        "CORE_PEER_MSPCONFIGPATH":
            f"{TEST_NETWORK}/organizations/peerOrganizations/org1.example.com/users/auditor@org1.example.com/msp",
        "CORE_PEER_ADDRESS": "localhost:7051",
    }
    cmd = [
        PEER_QUERY_BIN, "chaincode", "query",
        "-C", "mychannel", "-n", "gestiondocumental",
        "-c", json.dumps({"function": "ConsultarHistorial", "Args": [doc_id]}),
    ]
    out = subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=20)
    if out.returncode != 0:
        return {"error": out.stderr.strip()}
    try:
        return json.loads(out.stdout.strip())
    except json.JSONDecodeError as e:
        return {"error": f"json: {e}", "raw": out.stdout}


# ---------- Asignación de decisiones según mezcla ----------
def asignar_decisiones(n, mezcla_str):
    """Devuelve una lista de tuplas (revisor_aprueba, legal_aprueba) de longitud n."""
    aprobado, rech_rev, rech_legal = [int(x) for x in mezcla_str.split(",")]
    n_aprob = round(n * aprobado / 100)
    n_rechrev = round(n * rech_rev / 100)
    n_rechlegal = n - n_aprob - n_rechrev

    decisiones = []
    for _ in range(n_aprob):
        decisiones.append((True, True))
    for _ in range(n_rechrev):
        decisiones.append((False, None))  # No llega a legal
    for _ in range(n_rechlegal):
        decisiones.append((True, False))

    random.shuffle(decisiones)
    return decisiones


# ---------- Ejecuta una instancia ----------
def ejecutar_documento(cliente, pdf_local, pdf_vm_dir, proceso_key, version, decision_revisor, decision_legal):
    doc_id = Path(pdf_local).stem  # "DOC-A-001"
    pdf_vm_path = f"{pdf_vm_dir}/{Path(pdf_local).name}"

    registro = {
        "doc_id": doc_id,
        "pdf_path": pdf_vm_path,
        "decision_revisor": decision_revisor,
        "decision_legal": decision_legal,
        "inicio": datetime.now(timezone.utc).isoformat(),
        "process_instance_id": None,
        "estado_final_camunda": None,
        "ruta_seguida": [],
        "estado_onchain": None,
        "eventos_onchain": [],
        "ok_trazabilidad": False,
        "error": None,
    }

    try:
        # 1. Iniciar instancia
        resp = cliente.start_instance(proceso_key, {
            "docId":         {"value": doc_id, "type": "String"},
            "version":       {"value": version, "type": "Integer"},
            "pdfPath":       {"value": pdf_vm_path, "type": "String"},
            "nombreArchivo": {"value": Path(pdf_local).name, "type": "String"},
        })
        pi_id = resp["id"]
        registro["process_instance_id"] = pi_id

        # 2. User Task del registrador
        task_id = esperar_user_task(cliente, pi_id, "UT_CrearDocumentoYCargar")
        cliente.complete_task(task_id)
        registro["ruta_seguida"].append("UT_CrearDocumentoYCargar")

        # 3. User Task del revisor
        task_id = esperar_user_task(cliente, pi_id, "UT_RevisarDocumento")
        cliente.complete_task(task_id, variables={
            "aprobado":                    {"value": decision_revisor, "type": "Boolean"},
            "comentario":                  {"value": "Decisión escenario A", "type": "String"},
            "documentoAprobadoPorRevisor": {"value": decision_revisor, "type": "Boolean"},
        })
        registro["ruta_seguida"].append(
            "UT_RevisarDocumento(aprobado)" if decision_revisor else "UT_RevisarDocumento(rechazado)")

        # 4. Si rechazado por revisor → flujo va a corregir; ahí termina el escenario A
        if not decision_revisor:
            time.sleep(3)  # dar tiempo al worker para sincronizar on-chain
            registro["estado_final_camunda"] = "RECHAZADO_REVISOR_EN_CAMUNDA"
        else:
            # 5. User Task del legal
            task_id = esperar_user_task(cliente, pi_id, "UT_ValidacionLegalYCumplimiento")
            cliente.complete_task(task_id, variables={
                "aprobado":              {"value": decision_legal, "type": "Boolean"},
                "comentario":            {"value": "Decisión escenario A (legal)", "type": "String"},
                "cumpleValidacionLegal": {"value": decision_legal, "type": "Boolean"},
            })
            registro["ruta_seguida"].append(
                "UT_ValidacionLegalYCumplimiento(aprobado)" if decision_legal else "UT_ValidacionLegalYCumplimiento(rechazado)")

            if decision_legal:
                # 6. User Task del publicador
                task_id = esperar_user_task(cliente, pi_id, "UT_PublicarOArchivarVersionFinal")
                cliente.complete_task(task_id)
                registro["ruta_seguida"].append("UT_PublicarOArchivarVersionFinal")

                # 7. Esperar fin
                final = esperar_fin_instancia(cliente, pi_id)
                registro["estado_final_camunda"] = final.get("state")
            else:
                time.sleep(3)
                registro["estado_final_camunda"] = "RECHAZADO_LEGAL_EN_CAMUNDA"

        # 8. Consultar on-chain
        time.sleep(2)
        onchain = consultar_chaincode(doc_id)
        if "error" in onchain:
            registro["error"] = onchain["error"]
        else:
            registro["estado_onchain"] = onchain.get("estado_actual")
            registro["eventos_onchain"] = [e["event_type"] for e in onchain.get("historial", [])]

        # 9. Evaluar CT: el conjunto de eventos on-chain debe ser consistente con la ruta seguida
        registro["ok_trazabilidad"] = evaluar_trazabilidad(decision_revisor, decision_legal, registro["eventos_onchain"])

    except Exception as e:
        registro["error"] = str(e)

    registro["fin"] = datetime.now(timezone.utc).isoformat()
    return registro


def evaluar_trazabilidad(decision_revisor, decision_legal, eventos):
    """Comprueba que los eventos on-chain coinciden con las decisiones tomadas."""
    if not eventos:
        return False
    if "CREADO" not in eventos:
        return False

    if not decision_revisor:
        return "RECHAZADO_REVISOR" in eventos
    if not decision_legal:
        return "APROBADO_REVISOR" in eventos and "RECHAZADO_LEGAL" in eventos
    # Camino feliz
    return all(e in eventos for e in ["APROBADO_REVISOR", "APROBADO_LEGAL", "PUBLICADO"])


# ---------- Main ----------
def main():
    args = cargar_args()

    pdfs = sorted(Path(args.dataset).glob("*.pdf"))
    if not pdfs:
        print(f"No hay PDFs en {args.dataset}")
        return

    print(f"Encontrados {len(pdfs)} PDFs.")
    decisiones = asignar_decisiones(len(pdfs), args.mezcla)
    print(f"Decisiones: {decisiones}")

    cliente = CamundaClient(args.camunda, args.user, args.password)

    resultados = []
    for i, pdf in enumerate(pdfs):
        rev, leg = decisiones[i]
        print(f"\n[{i+1}/{len(pdfs)}] Procesando {pdf.name} (rev={rev}, leg={leg})")
        r = ejecutar_documento(cliente, pdf, args.pdf_dir_vm, args.proceso, 1, rev, leg)
        resultados.append(r)
        print(f"   -> ok_trazabilidad={r['ok_trazabilidad']}, onchain={r.get('estado_onchain')}, error={r.get('error')}")

        # Espera aleatoria 1-3s antes del siguiente
        time.sleep(random.uniform(1.0, 3.0))

    # ---- Reporte ----
    total = len(resultados)
    ok = sum(1 for r in resultados if r["ok_trazabilidad"])
    ct = (ok / total) * 100 if total else 0
    errores = [r for r in resultados if r["error"]]

    reporte = {
        "fecha": datetime.now(timezone.utc).isoformat(),
        "total": total,
        "exitos_trazabilidad": ok,
        "CT_porcentaje": round(ct, 2),
        "errores": len(errores),
        "mezcla_usada": args.mezcla,
        "detalle": resultados,
    }

    Path(args.reporte).write_text(json.dumps(reporte, indent=2, ensure_ascii=False))
    print(f"\n=== RESUMEN ===")
    print(f"Total: {total}")
    print(f"Trazabilidad OK: {ok}")
    print(f"CT: {ct:.2f}%")
    print(f"Errores: {len(errores)}")
    print(f"Reporte en: {args.reporte}")


if __name__ == "__main__":
    main()
