"""
Genera N PDFs sintéticos con texto aleatorio para el Escenario A del TFM.

Uso:
    python3 generar_dataset.py --cantidad 10 --salida ./dataset

Cada PDF tendrá:
- Un identificador único en el nombre (DOC-A-001.pdf, ..., DOC-A-NNN.pdf)
- Contenido textual aleatorio (lorem-ipsum estilo) entre 200 y 500 palabras
- Encabezado con metadatos: fecha, id, hash sintético
"""

import argparse
import os
import random
import string
from datetime import datetime, timezone
from pathlib import Path

try:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
    from reportlab.lib.units import cm
except ImportError:
    print("ERROR: necesitas instalar reportlab. Ejecuta: pip install reportlab")
    raise


PALABRAS = """
contrato cliente proveedor servicio entrega fecha plazo monto factura albaran
acuerdo confidencialidad legal cumplimiento auditoria revision documento version
politica procedimiento normativa estandar control evidencia trazabilidad blockchain
hash firma identidad rol responsable aprobacion rechazo publicacion archivo soporte
operativo financiero juridico tecnico administrativo gestion organizacion proyecto
ejecucion supervision validacion conformidad calidad seguridad confidencial publico
analisis informe recomendacion mejora hallazgo riesgo mitigacion accion seguimiento
ciclo etapa estado transicion historial inmutable verificable autoria autenticidad
""".split()


def parrafo_aleatorio(min_palabras=40, max_palabras=80):
    n = random.randint(min_palabras, max_palabras)
    palabras = [random.choice(PALABRAS) for _ in range(n)]
    palabras[0] = palabras[0].capitalize()
    return " ".join(palabras) + "."


def generar_pdf(path, doc_id):
    doc = SimpleDocTemplate(
        str(path),
        pagesize=A4,
        leftMargin=2 * cm,
        rightMargin=2 * cm,
        topMargin=2 * cm,
        bottomMargin=2 * cm,
    )
    estilos = getSampleStyleSheet()
    flujo = []

    flujo.append(Paragraph(f"<b>Documento de prueba — Escenario A</b>", estilos["Title"]))
    flujo.append(Spacer(1, 0.5 * cm))

    flujo.append(Paragraph(f"<b>ID:</b> {doc_id}", estilos["Normal"]))
    flujo.append(Paragraph(
        f"<b>Generado:</b> {datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}",
        estilos["Normal"],
    ))
    flujo.append(Paragraph(f"<b>Tipo:</b> documento_sintetico", estilos["Normal"]))
    flujo.append(Spacer(1, 0.7 * cm))

    n_parrafos = random.randint(4, 7)
    for _ in range(n_parrafos):
        flujo.append(Paragraph(parrafo_aleatorio(), estilos["BodyText"]))
        flujo.append(Spacer(1, 0.3 * cm))

    # Suffix aleatorio para garantizar que dos PDFs nunca sean idénticos
    suffix = "".join(random.choices(string.ascii_letters + string.digits, k=16))
    flujo.append(Paragraph(f"<i>noise:</i> {suffix}", estilos["Italic"]))

    doc.build(flujo)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cantidad", type=int, default=10)
    parser.add_argument("--salida", type=str, default="./dataset")
    parser.add_argument("--prefijo", type=str, default="DOC-A")
    args = parser.parse_args()

    salida = Path(args.salida)
    salida.mkdir(parents=True, exist_ok=True)

    for i in range(1, args.cantidad + 1):
        doc_id = f"{args.prefijo}-{i:03d}"
        path = salida / f"{doc_id}.pdf"
        generar_pdf(path, doc_id)
        print(f"[OK] {doc_id} -> {path}")

    print(f"\nGenerados {args.cantidad} PDFs en {salida.resolve()}")


if __name__ == "__main__":
    main()
