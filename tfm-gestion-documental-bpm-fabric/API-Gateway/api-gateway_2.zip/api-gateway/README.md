# API Gateway / Worker — BPM (Camunda 7) + Hyperledger Fabric

Worker de External Tasks de Camunda 7 + servidor HTTP para invocar el chaincode
`gestiondocumental` v1.1. Implementado en Go usando **Fabric Gateway SDK**.

## Decisiones de diseño clave

| Decisión | Justificación |
|---|---|
| **External Task / Worker** (pull) en vez de HTTP-Connector (push) | Patrón canónico de Camunda 7. Resiliente: si el worker cae, las tareas quedan en cola. |
| **Fabric Gateway SDK** en vez de `peer chaincode invoke` vía exec | Conexión gRPC persistente, errores tipados, TxID nativo. |
| **Pool de identidades por rol** | Cada método del chaincode invoca con la identidad correcta (`CrearDocumento` → registrador, `PublicarDocumento` → publicador, etc.), respetando la SoD criptográfica del chaincode. |
| **`pdfPath`** en vez de `contenidoB64` | Lectura del PDF desde disco en vez de strings grandes en variables Camunda. |
| **Topics de decisión separados** | `registrar-decision-revisor` y `registrar-decision-legal` sincronizan la decisión humana on-chain antes del gateway, evitando errores de estado on-chain. |

## Topics del worker

| Topic BPMN | Función chaincode | Identidad usada |
|---|---|---|
| `calcular-hash-crear-documento` | `CrearDocumento` | registrador |
| `persistir-hash-doc-guardar-offchain` | (solo off-chain) | — |
| `registrar-decision-revisor` | `AprobarRevision` | revisor |
| `registrar-decision-legal` | `AprobarLegal` | legal |
| `calcular-nuevo-hash-registrar-reenviado` | `RegistrarReenviado` | registrador |
| `actualizar-evidencia-onchain-version-offchain` | `ActualizarEvidencia` | registrador |
| `invocar-publicar-documento` | `PublicarDocumento` | publicador |
| `registrar-publicado-historial-verificable` | (cierre) | — |

## Variables esperadas en las external tasks

| Variable | Tipo | Notas |
|---|---|---|
| `docId` | String | Ej. `DOC-2026-0001` |
| `version` | Integer | 1, 2, 3... |
| `pdfPath` | String | Ruta absoluta al PDF en la VM |
| `nombreArchivo` | String | Nombre original |
| `aprobado` | Boolean | Para topics de decisión |
| `comentario` | String | Comentario de la decisión |

## Variables de entorno relevantes

| Variable | Descripción |
|---|---|
| `FABRIC_IDENTITIES_ROOT` | Carpeta padre con los MSP de cada rol (registrador, revisor, legal, publicador, auditor) |
| `FABRIC_USER_DOMAIN` | Dominio del usuario, default `org1.example.com` |
| `FABRIC_TLS_CERT_PATH` | TLS CA del peer |

## Compilar y correr

```bash
cd ~/proyecto-bpm-fabric/api-gateway
cp .env.example .env
# Edita CAMUNDA_PASSWORD si la cambiaste

go mod tidy
go run ./cmd
```
