package main

import (
	"context"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/joho/godotenv"

	"github.com/tfm/api-gateway/internal/camunda"
	"github.com/tfm/api-gateway/internal/config"
	"github.com/tfm/api-gateway/internal/fabric"
	"github.com/tfm/api-gateway/internal/handlers"
	"github.com/tfm/api-gateway/internal/offchain"
)

func main() {
	_ = godotenv.Load() // si no existe .env, se usan defaults / vars del entorno
	cfg := config.Load()

	// Off-chain
	off, err := offchain.NewRepo(cfg.OffchainRoot)
	if err != nil {
		log.Fatalf("offchain: %v", err)
	}
	log.Printf("[main] offchain en %s", cfg.OffchainRoot)

	// Fabric (no detiene el arranque si no está habilitado o falla la conexión: el worker registra el aviso)
	fab, err := fabric.New(fabric.Config{
		Enabled:        cfg.FabricEnabled,
		MSPID:          cfg.FabricMSPID,
		IdentitiesRoot: cfg.FabricIdentitiesRoot,
		UserDomain:     cfg.FabricUserDomain,
		TLSCertPath:    cfg.FabricTLSCertPath,
		PeerEndpoint:   cfg.FabricPeerEndpoint,
		GatewayPeer:    cfg.FabricGatewayPeer,
		ChannelName:    cfg.FabricChannelName,
		ChaincodeName:  cfg.FabricChaincodeName,
	})
	if err != nil {
		log.Printf("[main] fabric init AVISO: %v (continuando sin Fabric)", err)
		fab, _ = fabric.New(fabric.Config{Enabled: false, ChaincodeName: cfg.FabricChaincodeName})
	}
	defer fab.Close()
	log.Printf("[main] fabric enabled=%t", fab.Enabled())

	// Camunda client + worker
	cam := camunda.New(cfg.CamundaBaseURL, cfg.CamundaUser, cfg.CamundaPassword)
	worker := camunda.NewWorker(cam, fab, off, cfg.WorkerID, cfg.LockDuration, cfg.PollInterval)

	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()

	go worker.Run(ctx)

	// HTTP API
	api := &handlers.API{Fab: fab, Off: off}
	r := chi.NewRouter()
	r.Get("/health", api.Health)
	r.Post("/documentos", api.CrearDocumento)
	r.Post("/documentos/{docId}/aprobar-revision", api.AprobarRevision)
	r.Post("/documentos/{docId}/aprobar-legal", api.AprobarLegal)
	r.Post("/documentos/{docId}/publicar", api.Publicar)
	r.Post("/documentos/{docId}/reenviar", api.Reenviar)
	r.Post("/documentos/{docId}/actualizar-evidencia", api.ActualizarEvidencia)
	r.Get("/documentos/{docId}/historial", api.Historial)
	r.Get("/documentos/{docId}/verificar", api.Verificar)

	srv := &http.Server{
		Addr:              ":" + cfg.HTTPPort,
		Handler:           r,
		ReadHeaderTimeout: 5 * time.Second,
	}

	go func() {
		log.Printf("[main] HTTP API escuchando en :%s", cfg.HTTPPort)
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("http: %v", err)
		}
	}()

	<-ctx.Done()
	log.Println("[main] apagando...")
	shutdownCtx, cancelShutdown := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancelShutdown()
	_ = srv.Shutdown(shutdownCtx)
}
