package offchain

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"time"
)

// Repo guarda copias del archivo original en disco bajo una estructura
// por doc_id, calcula el SHA-256 sobre el archivo real y devuelve la ruta
// canónica donde quedó la evidencia off-chain.
type Repo struct {
	root string
}

func NewRepo(root string) (*Repo, error) {
	if err := os.MkdirAll(root, 0o755); err != nil {
		return nil, fmt.Errorf("creando offchain root: %w", err)
	}
	return &Repo{root: root}, nil
}

// SaveFromPath toma el archivo en srcPath, lo copia al repositorio off-chain
// bajo la carpeta del docID con nombre versionado, y devuelve la ruta destino
// junto con el SHA-256 del contenido original.
//
// Esta función reemplaza el viejo Save(contenidoB64) por una lectura real
// del filesystem, evitando pasar archivos grandes como variables Camunda.
func (r *Repo) SaveFromPath(srcPath, docID string, version int, originalName string) (path, hashHex string, err error) {
	if srcPath == "" {
		return "", "", fmt.Errorf("pdfPath vacío")
	}
	if _, err := os.Stat(srcPath); err != nil {
		return "", "", fmt.Errorf("pdfPath no accesible: %w", err)
	}

	cleanDoc := sanitize(docID)
	if cleanDoc == "" {
		cleanDoc = "doc"
	}
	cleanName := sanitize(originalName)
	if cleanName == "" {
		cleanName = "documento.pdf"
	}
	if !strings.HasSuffix(strings.ToLower(cleanName), ".pdf") {
		cleanName += ".pdf"
	}

	folder := filepath.Join(r.root, cleanDoc)
	if err := os.MkdirAll(folder, 0o755); err != nil {
		return "", "", err
	}

	dst := filepath.Join(folder, fmt.Sprintf("v%d_%s_%s",
		version,
		time.Now().UTC().Format("20060102T150405Z"),
		cleanName))

	if err := copyFile(srcPath, dst); err != nil {
		return "", "", err
	}

	hashHex, err = hashFile(dst)
	if err != nil {
		return "", "", err
	}
	return dst, hashHex, nil
}

// HashOf recalcula el SHA-256 de un archivo existente (verificación de integridad).
func (r *Repo) HashOf(path string) (string, error) {
	return hashFile(path)
}

// ---------- helpers ----------

func copyFile(src, dst string) error {
	in, err := os.Open(src)
	if err != nil {
		return fmt.Errorf("abriendo origen: %w", err)
	}
	defer in.Close()

	out, err := os.OpenFile(dst, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0o644)
	if err != nil {
		return fmt.Errorf("creando destino: %w", err)
	}
	defer out.Close()

	if _, err := io.Copy(out, in); err != nil {
		return fmt.Errorf("copiando: %w", err)
	}
	return nil
}

func hashFile(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", fmt.Errorf("abriendo archivo: %w", err)
	}
	defer f.Close()
	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return "", fmt.Errorf("leyendo archivo: %w", err)
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

func sanitize(v string) string {
	v = strings.TrimSpace(v)
	v = strings.ReplaceAll(v, "..", "")
	v = strings.ReplaceAll(v, "/", "_")
	v = strings.ReplaceAll(v, "\\", "_")
	v = strings.ReplaceAll(v, " ", "_")
	return v
}
