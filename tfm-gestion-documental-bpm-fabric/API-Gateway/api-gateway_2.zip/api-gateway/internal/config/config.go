package config

import (
	"os"
	"strconv"
	"time"
)

// Config agrupa todos los parámetros del Gateway.
type Config struct {
	// HTTP
	HTTPPort string

	// Camunda
	CamundaBaseURL  string
	CamundaUser     string
	CamundaPassword string
	WorkerID        string
	PollInterval    time.Duration
	LockDuration    int64 // ms

	// Off-chain
	OffchainRoot string

	// Fabric
	FabricEnabled       bool
	FabricMSPID         string
	FabricIdentitiesRoot string // Carpeta padre donde están los MSP de cada rol
	FabricUserDomain    string
	FabricTLSCertPath   string
	FabricPeerEndpoint  string
	FabricGatewayPeer   string
	FabricChannelName   string
	FabricChaincodeName string
}

// Load lee la configuración del entorno con valores por defecto seguros para piloto.
func Load() *Config {
	return &Config{
		HTTPPort:        getEnv("HTTP_PORT", "3000"),
		CamundaBaseURL:  getEnv("CAMUNDA_BASE_URL", "http://camunda:8080/engine-rest"),
		CamundaUser:     getEnv("CAMUNDA_USER", "demo"),
		CamundaPassword: getEnv("CAMUNDA_PASSWORD", "demo"),
		WorkerID:        getEnv("WORKER_ID", "api-gateway-worker"),
		PollInterval:    time.Duration(getEnvInt("POLL_INTERVAL_SECONDS", 5)) * time.Second,
		LockDuration:    int64(getEnvInt("LOCK_DURATION_MS", 60000)),
		OffchainRoot:    getEnv("OFFCHAIN_ROOT", "/opt/tfm-camunda/offchain"),

		FabricEnabled:        getEnvBool("FABRIC_ENABLED", false),
		FabricMSPID:          getEnv("FABRIC_MSP_ID", "Org1MSP"),
		FabricIdentitiesRoot: getEnv("FABRIC_IDENTITIES_ROOT", ""),
		FabricUserDomain:     getEnv("FABRIC_USER_DOMAIN", "org1.example.com"),
		FabricTLSCertPath:    getEnv("FABRIC_TLS_CERT_PATH", ""),
		FabricPeerEndpoint:   getEnv("FABRIC_PEER_ENDPOINT", "localhost:7051"),
		FabricGatewayPeer:    getEnv("FABRIC_GATEWAY_PEER", "peer0.org1.example.com"),
		FabricChannelName:    getEnv("FABRIC_CHANNEL_NAME", "mychannel"),
		FabricChaincodeName:  getEnv("FABRIC_CHAINCODE_NAME", "gestiondocumental"),
	}
}

func getEnv(key, def string) string {
	if v, ok := os.LookupEnv(key); ok && v != "" {
		return v
	}
	return def
}

func getEnvInt(key string, def int) int {
	if v, ok := os.LookupEnv(key); ok {
		if n, err := strconv.Atoi(v); err == nil {
			return n
		}
	}
	return def
}

func getEnvBool(key string, def bool) bool {
	if v, ok := os.LookupEnv(key); ok {
		if b, err := strconv.ParseBool(v); err == nil {
			return b
		}
	}
	return def
}
