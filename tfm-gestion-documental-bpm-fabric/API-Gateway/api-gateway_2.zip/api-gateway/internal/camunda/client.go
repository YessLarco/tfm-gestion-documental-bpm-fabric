package camunda

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"
)

// Client habla con el REST API de Camunda para el patrón external task.
type Client struct {
	baseURL  string
	user     string
	password string
	http     *http.Client
}

func New(baseURL, user, password string) *Client {
	return &Client{
		baseURL:  baseURL,
		user:     user,
		password: password,
		http:     &http.Client{Timeout: 30 * time.Second},
	}
}

// ---------- Tipos del API ----------

type FetchAndLockRequest struct {
	WorkerID string  `json:"workerId"`
	MaxTasks int     `json:"maxTasks"`
	Topics   []Topic `json:"topics"`
}

type Topic struct {
	TopicName    string `json:"topicName"`
	LockDuration int64  `json:"lockDuration"`
}

type ExternalTask struct {
	ID                  string                 `json:"id"`
	TopicName           string                 `json:"topicName"`
	WorkerID            string                 `json:"workerId"`
	ProcessInstanceID   string                 `json:"processInstanceId"`
	ProcessDefinitionID string                 `json:"processDefinitionId"`
	ActivityID          string                 `json:"activityId"`
	Variables           map[string]VariableVal `json:"variables"`
}

type VariableVal struct {
	Value     interface{} `json:"value"`
	Type      string      `json:"type"`
	ValueInfo interface{} `json:"valueInfo,omitempty"`
}

type CompleteRequest struct {
	WorkerID  string                 `json:"workerId"`
	Variables map[string]VariableVal `json:"variables"`
}

type FailureRequest struct {
	WorkerID     string `json:"workerId"`
	ErrorMessage string `json:"errorMessage"`
	ErrorDetails string `json:"errorDetails,omitempty"`
	Retries      int    `json:"retries"`
	RetryTimeout int64  `json:"retryTimeout"`
}

// ---------- Operaciones ----------

// FetchAndLock toma hasta maxTasks tareas externas de los topics dados, bloqueándolas.
func (c *Client) FetchAndLock(ctx context.Context, workerID string, lockMs int64, topics []string, maxTasks int) ([]ExternalTask, error) {
	tps := make([]Topic, 0, len(topics))
	for _, t := range topics {
		tps = append(tps, Topic{TopicName: t, LockDuration: lockMs})
	}
	body := FetchAndLockRequest{
		WorkerID: workerID,
		MaxTasks: maxTasks,
		Topics:   tps,
	}
	var out []ExternalTask
	if err := c.do(ctx, "POST", "/external-task/fetchAndLock", body, &out); err != nil {
		return nil, err
	}
	return out, nil
}

// Complete cierra una external task con variables resultado.
func (c *Client) Complete(ctx context.Context, taskID, workerID string, vars map[string]VariableVal) error {
	body := CompleteRequest{WorkerID: workerID, Variables: vars}
	return c.do(ctx, "POST", "/external-task/"+taskID+"/complete", body, nil)
}

// Failure notifica un error de procesamiento sobre una external task.
func (c *Client) Failure(ctx context.Context, taskID, workerID, msg, details string, retries int, retryTimeoutMs int64) error {
	body := FailureRequest{
		WorkerID:     workerID,
		ErrorMessage: msg,
		ErrorDetails: details,
		Retries:      retries,
		RetryTimeout: retryTimeoutMs,
	}
	return c.do(ctx, "POST", "/external-task/"+taskID+"/failure", body, nil)
}

// ---------- helpers ----------

func (c *Client) do(ctx context.Context, method, path string, body interface{}, out interface{}) error {
	var reqBody io.Reader
	if body != nil {
		b, err := json.Marshal(body)
		if err != nil {
			return fmt.Errorf("marshal body: %w", err)
		}
		reqBody = bytes.NewReader(b)
	}
	req, err := http.NewRequestWithContext(ctx, method, c.baseURL+path, reqBody)
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")
	req.SetBasicAuth(c.user, c.password)

	resp, err := c.http.Do(req)
	if err != nil {
		return fmt.Errorf("http: %w", err)
	}
	defer resp.Body.Close()

	respBody, _ := io.ReadAll(resp.Body)
	if resp.StatusCode >= 300 {
		return fmt.Errorf("camunda %s %s: %d - %s", method, path, resp.StatusCode, string(respBody))
	}
	if out != nil && len(respBody) > 0 {
		if err := json.Unmarshal(respBody, out); err != nil {
			return fmt.Errorf("unmarshal: %w", err)
		}
	}
	return nil
}

// String es util para sacar variables de tipo String de la tarea externa.
func (t ExternalTask) String(name string) string {
	if v, ok := t.Variables[name]; ok {
		if s, ok := v.Value.(string); ok {
			return s
		}
	}
	return ""
}

// Int es util para sacar variables enteras de la tarea externa.
func (t ExternalTask) Int(name string) int {
	if v, ok := t.Variables[name]; ok {
		switch n := v.Value.(type) {
		case float64:
			return int(n)
		case int:
			return n
		}
	}
	return 0
}

// Bool es util para sacar variables booleanas de la tarea externa.
func (t ExternalTask) Bool(name string) bool {
	if v, ok := t.Variables[name]; ok {
		if b, ok := v.Value.(bool); ok {
			return b
		}
	}
	return false
}

// VarString construye una variable Camunda de tipo String para complete.
func VarString(v string) VariableVal { return VariableVal{Value: v, Type: "String"} }

// VarInt construye una variable Camunda de tipo Integer para complete.
func VarInt(v int) VariableVal { return VariableVal{Value: v, Type: "Integer"} }

// VarBool construye una variable Camunda de tipo Boolean para complete.
func VarBool(v bool) VariableVal { return VariableVal{Value: v, Type: "Boolean"} }
