package camunda

import (
	"context"
	"fmt"
	"log"
	"time"

	"github.com/tfm/api-gateway/internal/fabric"
	"github.com/tfm/api-gateway/internal/offchain"
)

// Worker hace polling sobre todos los topics y los procesa.
type Worker struct {
	client       *Client
	fabric       *fabric.Client
	offchain     *offchain.Repo
	workerID     string
	lockMs       int64
	pollInterval time.Duration
	topics       []string
}

func NewWorker(client *Client, fab *fabric.Client, off *offchain.Repo, workerID string, lockMs int64, poll time.Duration) *Worker {
	return &Worker{
		client:       client,
		fabric:       fab,
		offchain:     off,
		workerID:     workerID,
		lockMs:       lockMs,
		pollInterval: poll,
		topics: []string{
			// Topics originales del BPMN
			"calcular-hash-crear-documento",
			"persistir-hash-doc-guardar-offchain",
			"calcular-nuevo-hash-registrar-reenviado",
			"actualizar-evidencia-onchain-version-offchain",
			"invocar-publicar-documento",
			"registrar-publicado-historial-verificable",

			// Topics nuevos para sincronizar decisiones humanas con Fabric
			// (cierran el gap de rechazos: el BPMN debe disparar estos antes
			// de que el flujo entre a un gateway de rechazo)
			"registrar-decision-revisor",
			"registrar-decision-legal",
		},
	}
}

// Run arranca el loop de fetch-and-lock + procesamiento hasta que el contexto se cancele.
func (w *Worker) Run(ctx context.Context) {
	log.Printf("[worker] iniciando: workerId=%s, topics=%d, fabric=%t",
		w.workerID, len(w.topics), w.fabric.Enabled())
	for {
		select {
		case <-ctx.Done():
			log.Println("[worker] detenido por contexto")
			return
		default:
		}

		tasks, err := w.client.FetchAndLock(ctx, w.workerID, w.lockMs, w.topics, 10)
		if err != nil {
			log.Printf("[worker] fetchAndLock error: %v", err)
			time.Sleep(w.pollInterval)
			continue
		}

		if len(tasks) == 0 {
			time.Sleep(w.pollInterval)
			continue
		}

		for _, t := range tasks {
			w.handle(ctx, t)
		}
	}
}

// handle despacha cada external task al método correspondiente según su topicName.
func (w *Worker) handle(ctx context.Context, t ExternalTask) {
	log.Printf("[worker] task=%s topic=%s instance=%s", t.ID, t.TopicName, t.ProcessInstanceID)

	var (
		vars map[string]VariableVal
		err  error
	)

	switch t.TopicName {
	case "calcular-hash-crear-documento":
		vars, err = w.calcularHashCrear(t)
	case "persistir-hash-doc-guardar-offchain":
		vars, err = w.persistirHashCrear(t)
	case "calcular-nuevo-hash-registrar-reenviado":
		vars, err = w.calcularNuevoHashReenviado(t)
	case "actualizar-evidencia-onchain-version-offchain":
		vars, err = w.actualizarEvidencia(t)
	case "invocar-publicar-documento":
		vars, err = w.invocarPublicar(t)
	case "registrar-publicado-historial-verificable":
		vars, err = w.registrarPublicado(t)
	case "registrar-decision-revisor":
		vars, err = w.registrarDecisionRevisor(t)
	case "registrar-decision-legal":
		vars, err = w.registrarDecisionLegal(t)
	default:
		err = fmt.Errorf("topic desconocido: %s", t.TopicName)
	}

	if err != nil {
		log.Printf("[worker] task=%s error: %v", t.ID, err)
		_ = w.client.Failure(ctx, t.ID, w.workerID, err.Error(), "", 3, 10000)
		return
	}

	if err := w.client.Complete(ctx, t.ID, w.workerID, vars); err != nil {
		log.Printf("[worker] task=%s complete error: %v", t.ID, err)
		return
	}
	log.Printf("[worker] task=%s completed", t.ID)
}

// ---------------------------------------------------------------------------
// Variables de proceso esperadas en cada external task (vienen de Camunda):
//   - docId            (String)   identificador único del documento (ej. DOC-2026-0001)
//   - version          (Integer)  número de versión
//   - tipo             (String)   tipo documental (opcional)
//   - pdfPath          (String)   RUTA absoluta al archivo en disco (reemplaza contenidoB64)
//   - nombreArchivo    (String)   nombre original del archivo
//   - aprobado         (Boolean)  para los topics de decisión (revisor/legal)
//   - comentario       (String)   comentario de la decisión
// ---------------------------------------------------------------------------

// calcularHashCrear lee el PDF de pdfPath, lo copia al off-chain, calcula
// SHA-256 e invoca CrearDocumento en el chaincode.
func (w *Worker) calcularHashCrear(t ExternalTask) (map[string]VariableVal, error) {
	docID := t.String("docId")
	version := t.Int("version")
	if version == 0 {
		version = 1
	}
	pdfPath := t.String("pdfPath")
	nombre := t.String("nombreArchivo")

	rutaOff, hash, err := w.offchain.SaveFromPath(pdfPath, docID, version, nombre)
	if err != nil {
		return nil, err
	}

	txID, fabErr := w.fabric.CrearDocumento(docID, hash, version)
	if fabErr != nil {
		log.Printf("[worker] fabric.CrearDocumento aviso: %v", fabErr)
	}

	return map[string]VariableVal{
		"hash":      VarString(hash),
		"rutaOff":   VarString(rutaOff),
		"txId":      VarString(txID),
		"eventoOn":  VarString("CREADO"),
		"timestamp": VarString(time.Now().UTC().Format(time.RFC3339)),
	}, nil
}

func (w *Worker) persistirHashCrear(t ExternalTask) (map[string]VariableVal, error) {
	docID := t.String("docId")
	log.Printf("[worker] persistir metadata para %s", docID)
	return map[string]VariableVal{
		"persisted": VarBool(true),
	}, nil
}

// calcularNuevoHashReenviado lee el PDF reenviado (nueva versión), lo copia
// al off-chain y llama RegistrarReenviado en el chaincode.
//
// IMPORTANTE: para que esto funcione, el documento debe estar previamente en
// estado RECHAZADO_REVISOR o RECHAZADO_LEGAL on-chain. Eso se logra mediante
// los topics registrar-decision-revisor o registrar-decision-legal con
// aprobado=false antes de entrar a este reenvío.
func (w *Worker) calcularNuevoHashReenviado(t ExternalTask) (map[string]VariableVal, error) {
	docID := t.String("docId")
	version := t.Int("version")
	pdfPath := t.String("pdfPath")
	nombre := t.String("nombreArchivo")

	rutaOff, hash, err := w.offchain.SaveFromPath(pdfPath, docID, version, nombre)
	if err != nil {
		return nil, err
	}

	txID, fabErr := w.fabric.RegistrarReenviado(docID, hash, version)
	if fabErr != nil {
		log.Printf("[worker] fabric.RegistrarReenviado aviso: %v", fabErr)
	}

	return map[string]VariableVal{
		"hash":     VarString(hash),
		"rutaOff":  VarString(rutaOff),
		"txId":     VarString(txID),
		"eventoOn": VarString("REENVIADO"),
	}, nil
}

// actualizarEvidencia se invoca cuando hay un cambio de evidencia que no implica
// un cambio de estado en el flujo (por ejemplo, reconciliación off/on-chain).
func (w *Worker) actualizarEvidencia(t ExternalTask) (map[string]VariableVal, error) {
	docID := t.String("docId")
	version := t.Int("version")
	hash := t.String("hash")

	// Si el hash no viene en variables, intentar recalcular desde pdfPath
	if hash == "" {
		pdfPath := t.String("pdfPath")
		if pdfPath != "" {
			h, err := w.offchain.HashOf(pdfPath)
			if err == nil {
				hash = h
			}
		}
	}

	txID, fabErr := w.fabric.ActualizarEvidencia(docID, hash, version)
	if fabErr != nil {
		log.Printf("[worker] fabric.ActualizarEvidencia aviso: %v", fabErr)
	}

	return map[string]VariableVal{
		"txId":     VarString(txID),
		"hash":     VarString(hash),
		"eventoOn": VarString("EVIDENCIA_ACTUALIZADA"),
	}, nil
}

func (w *Worker) invocarPublicar(t ExternalTask) (map[string]VariableVal, error) {
	docID := t.String("docId")

	txID, fabErr := w.fabric.PublicarDocumento(docID)
	if fabErr != nil {
		log.Printf("[worker] fabric.PublicarDocumento aviso: %v", fabErr)
	}

	return map[string]VariableVal{
		"txId":     VarString(txID),
		"eventoOn": VarString("PUBLICADO"),
	}, nil
}

// registrarPublicado es el cierre del flujo: no llama a Fabric porque la
// publicación ya quedó on-chain en el paso anterior. Solo retorna variables
// de cierre para Camunda.
func (w *Worker) registrarPublicado(t ExternalTask) (map[string]VariableVal, error) {
	docID := t.String("docId")
	log.Printf("[worker] registrando cierre publicado %s", docID)
	return map[string]VariableVal{
		"historialVerificable": VarBool(true),
		"timestampPublicacion": VarString(time.Now().UTC().Format(time.RFC3339)),
	}, nil
}

// ---------------------------------------------------------------------------
// Topics nuevos para sincronizar decisiones humanas con Fabric.
//
// Estos cierran el gap entre Camunda y Fabric en los rechazos: cuando el
// revisor (o el legal) toma una decisión en una User Task, el BPMN debe
// disparar este topic ANTES de entrar al gateway de aprobación/rechazo.
// Así, si la decisión fue rechazar, el documento queda en estado
// RECHAZADO_REVISOR (o RECHAZADO_LEGAL) on-chain, y RegistrarReenviado
// podrá ejecutarse después sin que el chaincode lo bloquee.
// ---------------------------------------------------------------------------

func (w *Worker) registrarDecisionRevisor(t ExternalTask) (map[string]VariableVal, error) {
	docID := t.String("docId")
	aprobado := t.Bool("aprobado")
	comentario := t.String("comentario")

	txID, fabErr := w.fabric.AprobarRevision(docID, aprobado, comentario)
	if fabErr != nil {
		log.Printf("[worker] fabric.AprobarRevision aviso: %v", fabErr)
	}

	evento := "APROBADO_REVISOR"
	if !aprobado {
		evento = "RECHAZADO_REVISOR"
	}

	return map[string]VariableVal{
		"txId":     VarString(txID),
		"eventoOn": VarString(evento),
	}, nil
}

func (w *Worker) registrarDecisionLegal(t ExternalTask) (map[string]VariableVal, error) {
	docID := t.String("docId")
	aprobado := t.Bool("aprobado")
	comentario := t.String("comentario")

	txID, fabErr := w.fabric.AprobarLegal(docID, aprobado, comentario)
	if fabErr != nil {
		log.Printf("[worker] fabric.AprobarLegal aviso: %v", fabErr)
	}

	evento := "APROBADO_LEGAL"
	if !aprobado {
		evento = "RECHAZADO_LEGAL"
	}

	return map[string]VariableVal{
		"txId":     VarString(txID),
		"eventoOn": VarString(evento),
	}, nil
}
