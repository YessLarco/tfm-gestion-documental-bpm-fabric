package fabric

import (
	"crypto/x509"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/hyperledger/fabric-gateway/pkg/client"
	"github.com/hyperledger/fabric-gateway/pkg/identity"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials"
)

// Client mantiene un POOL de conexiones a Fabric, una por cada rol.
// Cada método del chaincode usa la identidad correspondiente al rol que el
// chaincode espera (registrador, revisor, legal, publicador, auditor).
//
// Esto resuelve el "acceso denegado" cuando el Gateway usaba una sola identidad
// fija para todas las operaciones.
type Client struct {
	enabled       bool
	chaincodeName string

	// gateways por rol (clave: "registrador", "revisor", "legal", "publicador", "auditor")
	contracts map[string]*client.Contract
	gateways  []*client.Gateway
}

// Config principal del cliente Fabric.
type Config struct {
	Enabled       bool
	MSPID         string
	ChannelName   string
	ChaincodeName string

	// Conexión gRPC al peer (compartida por todas las identidades)
	PeerEndpoint string
	GatewayPeer  string
	TLSCertPath  string

	// Raíz donde están las identidades por rol. Estructura esperada:
	//   {IdentitiesRoot}/{rol}@org1.example.com/msp/signcerts/cert.pem
	//   {IdentitiesRoot}/{rol}@org1.example.com/msp/keystore/*_sk
	IdentitiesRoot string

	// Dominio del usuario (default: org1.example.com)
	UserDomain string
}

// Roles soportados. Si añades nuevos, agrégalos aquí.
var Roles = []string{"registrador", "revisor", "legal", "publicador", "auditor"}

func New(cfg Config) (*Client, error) {
	c := &Client{
		enabled:       cfg.Enabled,
		chaincodeName: cfg.ChaincodeName,
		contracts:     make(map[string]*client.Contract),
	}

	if !cfg.Enabled {
		return c, nil
	}

	domain := cfg.UserDomain
	if domain == "" {
		domain = "org1.example.com"
	}

	for _, role := range Roles {
		userDir := filepath.Join(cfg.IdentitiesRoot, fmt.Sprintf("%s@%s", role, domain), "msp")
		certPath := filepath.Join(userDir, "signcerts", "cert.pem")
		keyPath, err := findKeyFile(filepath.Join(userDir, "keystore"))
		if err != nil {
			return nil, fmt.Errorf("no se encontró la clave privada de %s: %w", role, err)
		}

		conn, err := newGrpcConnection(cfg.TLSCertPath, cfg.PeerEndpoint, cfg.GatewayPeer)
		if err != nil {
			return nil, fmt.Errorf("grpc %s: %w", role, err)
		}

		id, err := newIdentity(cfg.MSPID, certPath)
		if err != nil {
			return nil, fmt.Errorf("identity %s: %w", role, err)
		}

		sign, err := newSign(keyPath)
		if err != nil {
			return nil, fmt.Errorf("sign %s: %w", role, err)
		}

		gw, err := client.Connect(
			id,
			client.WithSign(sign),
			client.WithClientConnection(conn),
			client.WithEvaluateTimeout(5*time.Second),
			client.WithEndorseTimeout(15*time.Second),
			client.WithSubmitTimeout(5*time.Second),
			client.WithCommitStatusTimeout(1*time.Minute),
		)
		if err != nil {
			return nil, fmt.Errorf("gateway connect %s: %w", role, err)
		}

		contract := gw.GetNetwork(cfg.ChannelName).GetContract(cfg.ChaincodeName)
		c.contracts[role] = contract
		c.gateways = append(c.gateways, gw)
	}

	return c, nil
}

func (c *Client) Close() {
	for _, gw := range c.gateways {
		_ = gw.Close()
	}
}

func (c *Client) Enabled() bool { return c.enabled }

// ============================================================================
// Métodos del chaincode, cada uno con la identidad del rol correspondiente.
// ============================================================================

func (c *Client) CrearDocumento(docID, hash string, version int) (string, error) {
	return c.submit("registrador", "CrearDocumento", docID, hash, fmt.Sprintf("%d", version))
}

func (c *Client) AprobarRevision(docID string, aprobado bool, comentario string) (string, error) {
	return c.submit("revisor", "AprobarRevision", docID, fmt.Sprintf("%t", aprobado), comentario)
}

func (c *Client) AprobarLegal(docID string, aprobado bool, comentario string) (string, error) {
	return c.submit("legal", "AprobarLegal", docID, fmt.Sprintf("%t", aprobado), comentario)
}

func (c *Client) PublicarDocumento(docID string) (string, error) {
	return c.submit("publicador", "PublicarDocumento", docID)
}

func (c *Client) RegistrarReenviado(docID, nuevoHash string, nuevaVersion int) (string, error) {
	return c.submit("registrador", "RegistrarReenviado", docID, nuevoHash, fmt.Sprintf("%d", nuevaVersion))
}

func (c *Client) ActualizarEvidencia(docID, nuevoHash string, version int) (string, error) {
	return c.submit("registrador", "ActualizarEvidencia", docID, nuevoHash, fmt.Sprintf("%d", version))
}

// Las consultas las hacemos con la identidad del auditor por convención.
func (c *Client) ConsultarHistorial(docID string) ([]byte, error) {
	if !c.enabled {
		return nil, ErrFabricDisabled
	}
	return c.contracts["auditor"].EvaluateTransaction("ConsultarHistorial", docID)
}

func (c *Client) VerificarIntegridad(docID, hashEsperado string) ([]byte, error) {
	if !c.enabled {
		return nil, ErrFabricDisabled
	}
	return c.contracts["auditor"].EvaluateTransaction("VerificarIntegridad", docID, hashEsperado)
}

// submit envía una transacción con la identidad del rol indicado.
func (c *Client) submit(role, fn string, args ...string) (string, error) {
	if !c.enabled {
		return "", ErrFabricDisabled
	}
	contract, ok := c.contracts[role]
	if !ok {
		return "", fmt.Errorf("identidad para rol %s no inicializada", role)
	}
	proposal, err := contract.NewProposal(fn, client.WithArguments(args...))
	if err != nil {
		return "", fmt.Errorf("proposal: %w", err)
	}
	tx, err := proposal.Endorse()
	if err != nil {
		return "", fmt.Errorf("endorse: %w", err)
	}
	commit, err := tx.Submit()
	if err != nil {
		return "", fmt.Errorf("submit: %w", err)
	}
	status, err := commit.Status()
	if err != nil {
		return "", fmt.Errorf("status: %w", err)
	}
	if !status.Successful {
		return "", fmt.Errorf("transacción no exitosa: code=%d", status.Code)
	}
	return tx.TransactionID(), nil
}

var ErrFabricDisabled = errors.New("fabric deshabilitado (FABRIC_ENABLED=false)")

// ---------- helpers ----------

// findKeyFile localiza el archivo *_sk dentro de la carpeta keystore.
// (Su nombre cambia entre redes; por eso no se puede hardcodear).
func findKeyFile(keystoreDir string) (string, error) {
	entries, err := os.ReadDir(keystoreDir)
	if err != nil {
		return "", err
	}
	for _, e := range entries {
		name := e.Name()
		if strings.HasSuffix(name, "_sk") || strings.HasSuffix(name, ".pem") {
			return filepath.Join(keystoreDir, name), nil
		}
	}
	return "", fmt.Errorf("no se encontró archivo de clave en %s", keystoreDir)
}

func newGrpcConnection(tlsCertPath, peerEndpoint, gatewayPeer string) (*grpc.ClientConn, error) {
	cert, err := os.ReadFile(tlsCertPath)
	if err != nil {
		return nil, fmt.Errorf("leyendo TLS cert: %w", err)
	}
	pool := x509.NewCertPool()
	pool.AppendCertsFromPEM(cert)
	creds := credentials.NewClientTLSFromCert(pool, gatewayPeer)
	return grpc.NewClient(peerEndpoint, grpc.WithTransportCredentials(creds))
}

func newIdentity(mspID, certPath string) (*identity.X509Identity, error) {
	certPEM, err := os.ReadFile(certPath)
	if err != nil {
		return nil, fmt.Errorf("leyendo cert: %w", err)
	}
	cert, err := identity.CertificateFromPEM(certPEM)
	if err != nil {
		return nil, err
	}
	return identity.NewX509Identity(mspID, cert)
}

func newSign(keyPath string) (identity.Sign, error) {
	keyPEM, err := os.ReadFile(keyPath)
	if err != nil {
		return nil, fmt.Errorf("leyendo private key: %w", err)
	}
	privateKey, err := identity.PrivateKeyFromPEM(keyPEM)
	if err != nil {
		return nil, err
	}
	return identity.NewPrivateKeySign(privateKey)
}
