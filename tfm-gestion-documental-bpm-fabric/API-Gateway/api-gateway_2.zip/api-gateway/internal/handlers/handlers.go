package handlers

import (
	"encoding/json"
	"net/http"

	"github.com/tfm/api-gateway/internal/fabric"
	"github.com/tfm/api-gateway/internal/offchain"
)

// API agrupa los handlers REST para invocar el chaincode desde clientes externos
// (Postman, scripts Python de pruebas, etc.). Camunda no usa estos endpoints
// porque su patrón es External Task; aquí van utilidades para el piloto y
// verificación independiente.
type API struct {
	Fab *fabric.Client
	Off *offchain.Repo
}

func (a *API) Health(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, map[string]any{
		"status":        "ok",
		"fabricEnabled": a.Fab.Enabled(),
	})
}

// POST /documentos  body: { "docId": "...", "hash": "...", "version": 1 }
func (a *API) CrearDocumento(w http.ResponseWriter, r *http.Request) {
	var req struct {
		DocID   string `json:"docId"`
		Hash    string `json:"hash"`
		Version int    `json:"version"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeErr(w, http.StatusBadRequest, err)
		return
	}
	tx, err := a.Fab.CrearDocumento(req.DocID, req.Hash, req.Version)
	if err != nil {
		writeErr(w, http.StatusBadGateway, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"txId": tx})
}

// POST /documentos/{docId}/aprobar-revision  body: { "aprobado": true, "comentario": "..." }
func (a *API) AprobarRevision(w http.ResponseWriter, r *http.Request) {
	docID := r.PathValue("docId")
	var req struct {
		Aprobado   bool   `json:"aprobado"`
		Comentario string `json:"comentario"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeErr(w, http.StatusBadRequest, err)
		return
	}
	tx, err := a.Fab.AprobarRevision(docID, req.Aprobado, req.Comentario)
	if err != nil {
		writeErr(w, http.StatusBadGateway, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"txId": tx})
}

// POST /documentos/{docId}/aprobar-legal
func (a *API) AprobarLegal(w http.ResponseWriter, r *http.Request) {
	docID := r.PathValue("docId")
	var req struct {
		Aprobado   bool   `json:"aprobado"`
		Comentario string `json:"comentario"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeErr(w, http.StatusBadRequest, err)
		return
	}
	tx, err := a.Fab.AprobarLegal(docID, req.Aprobado, req.Comentario)
	if err != nil {
		writeErr(w, http.StatusBadGateway, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"txId": tx})
}

// POST /documentos/{docId}/publicar
func (a *API) Publicar(w http.ResponseWriter, r *http.Request) {
	docID := r.PathValue("docId")
	tx, err := a.Fab.PublicarDocumento(docID)
	if err != nil {
		writeErr(w, http.StatusBadGateway, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"txId": tx})
}

// POST /documentos/{docId}/reenviar  body: { "nuevoHash": "...", "nuevaVersion": 2 }
func (a *API) Reenviar(w http.ResponseWriter, r *http.Request) {
	docID := r.PathValue("docId")
	var req struct {
		NuevoHash    string `json:"nuevoHash"`
		NuevaVersion int    `json:"nuevaVersion"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeErr(w, http.StatusBadRequest, err)
		return
	}
	tx, err := a.Fab.RegistrarReenviado(docID, req.NuevoHash, req.NuevaVersion)
	if err != nil {
		writeErr(w, http.StatusBadGateway, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"txId": tx})
}

// POST /documentos/{docId}/actualizar-evidencia  body: { "nuevoHash": "...", "version": 1 }
func (a *API) ActualizarEvidencia(w http.ResponseWriter, r *http.Request) {
	docID := r.PathValue("docId")
	var req struct {
		NuevoHash string `json:"nuevoHash"`
		Version   int    `json:"version"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeErr(w, http.StatusBadRequest, err)
		return
	}
	tx, err := a.Fab.ActualizarEvidencia(docID, req.NuevoHash, req.Version)
	if err != nil {
		writeErr(w, http.StatusBadGateway, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"txId": tx})
}

// GET /documentos/{docId}/historial
func (a *API) Historial(w http.ResponseWriter, r *http.Request) {
	docID := r.PathValue("docId")
	out, err := a.Fab.ConsultarHistorial(docID)
	if err != nil {
		writeErr(w, http.StatusBadGateway, err)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_, _ = w.Write(out)
}

// GET /documentos/{docId}/verificar?hash=...
func (a *API) Verificar(w http.ResponseWriter, r *http.Request) {
	docID := r.PathValue("docId")
	hash := r.URL.Query().Get("hash")
	out, err := a.Fab.VerificarIntegridad(docID, hash)
	if err != nil {
		writeErr(w, http.StatusBadGateway, err)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_, _ = w.Write(out)
}

// ---------- helpers ----------

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func writeErr(w http.ResponseWriter, code int, err error) {
	writeJSON(w, code, map[string]string{"error": err.Error()})
}
