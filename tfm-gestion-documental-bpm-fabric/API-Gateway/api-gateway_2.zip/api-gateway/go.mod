module github.com/tfm/api-gateway

go 1.22

require (
	github.com/go-chi/chi/v5 v5.1.0
	github.com/hyperledger/fabric-gateway v1.7.0
	github.com/joho/godotenv v1.5.1
	google.golang.org/grpc v1.66.0
)
