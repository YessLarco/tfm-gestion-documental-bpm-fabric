package contract

import (
	"errors"
	"fmt"

	"github.com/hyperledger/fabric-contract-api-go/contractapi"
	"github.com/hyperledger/fabric-chaincode-go/pkg/cid"
)

// getActorRole devuelve el atributo "role" embebido en el certificado X.509
// del invocador. Si el certificado no trae el atributo, devuelve error.
// Este es el mecanismo central de ABAC (Attribute-Based Access Control).
func getActorRole(ctx contractapi.TransactionContextInterface) (string, error) {
	role, ok, err := cid.GetAttributeValue(ctx.GetStub(), "role")
	if err != nil {
		return "", fmt.Errorf("error leyendo atributo role: %w", err)
	}
	if !ok {
		return "", errors.New("el certificado del invocador no contiene atributo 'role'")
	}
	return role, nil
}

// getActorID devuelve el identificador único del invocador (clientID),
// derivado del certificado X.509. Se usa para el campo actor_id del payload
// y para validar SoD-1.
func getActorID(ctx contractapi.TransactionContextInterface) (string, error) {
	id, err := cid.GetID(ctx.GetStub())
	if err != nil {
		return "", fmt.Errorf("error obteniendo clientID: %w", err)
	}
	return id, nil
}

// requiereRol verifica que el rol del invocador coincida con el esperado.
// Si no, devuelve un error que aborta la transacción (Throw Error según tabla 3).
func requiereRol(ctx contractapi.TransactionContextInterface, rolEsperado string) (string, string, error) {
	rol, err := getActorRole(ctx)
	if err != nil {
		return "", "", err
	}
	if rol != rolEsperado {
		return "", "", fmt.Errorf("acceso denegado: se requiere role=%s, el invocador tiene role=%s", rolEsperado, rol)
	}
	actorID, err := getActorID(ctx)
	if err != nil {
		return "", "", err
	}
	return rol, actorID, nil
}

// getTimestamp devuelve el timestamp de la transacción en formato RFC3339.
// Se usa el timestamp del peer (no el del cliente) para que sea verificable y
// reproducible en cualquier nodo de la red.
func getTimestamp(ctx contractapi.TransactionContextInterface) (string, error) {
	ts, err := ctx.GetStub().GetTxTimestamp()
	if err != nil {
		return "", fmt.Errorf("error obteniendo timestamp: %w", err)
	}
	return ts.AsTime().UTC().Format("2006-01-02T15:04:05Z"), nil
}
