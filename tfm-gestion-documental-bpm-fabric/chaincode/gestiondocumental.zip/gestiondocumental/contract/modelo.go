package contract

// Estados del ciclo de vida documental (tabla 2 del documento del TFM).
const (
	EstadoCreado          = "CREADO"
	EstadoAprobadoRevisor = "APROBADO_REVISOR"
	EstadoRechazadoRevisor = "RECHAZADO_REVISOR"
	EstadoAprobadoLegal   = "APROBADO_LEGAL"
	EstadoRechazadoLegal  = "RECHAZADO_LEGAL"
	EstadoPublicado       = "PUBLICADO"
)

// Roles válidos para SoD (tabla 2).
const (
	RolRegistrador = "registrador"
	RolRevisor     = "revisor"
	RolLegal       = "legal"
	RolPublicador  = "publicador"
	RolAuditor     = "auditor"
)

// Tipos de evento registrados en el historial on-chain.
const (
	EventoCreado            = "CREADO"
	EventoAprobadoRevisor   = "APROBADO_REVISOR"
	EventoRechazadoRevisor  = "RECHAZADO_REVISOR"
	EventoAprobadoLegal     = "APROBADO_LEGAL"
	EventoRechazadoLegal    = "RECHAZADO_LEGAL"
	EventoPublicado         = "PUBLICADO"
	EventoReenviado         = "REENVIADO"
	EventoEvidenciaUpdated  = "EVIDENCIA_ACTUALIZADA"
)

// Documento es la estructura que persiste en el world state.
// Cumple el esquema de payload mínimo definido en la tabla 2 del documento.
type Documento struct {
	DocID         string  `json:"doc_id"`
	DocumentHash  string  `json:"document_hash"`
	Version       int     `json:"version"`
	EstadoActual  string  `json:"estado_actual"`
	RegistradorID string  `json:"registrador_id"` // actor_id del que invocó crearDocumento (clave para SoD-1)
	RevisorID     string  `json:"revisor_id,omitempty"`
	LegalID       string  `json:"legal_id,omitempty"`
	PublicadorID  string  `json:"publicador_id,omitempty"`
	Historial     []Evento `json:"historial"`
}

// Evento representa una transición registrada inmutablemente.
type Evento struct {
	EventType string `json:"event_type"`
	ActorID   string `json:"actor_id"`
	ActorRole string `json:"actor_role"`
	Hash      string `json:"hash,omitempty"`
	Version   int    `json:"version,omitempty"`
	Timestamp string `json:"timestamp"`
	Comentario string `json:"comentario,omitempty"`
}
