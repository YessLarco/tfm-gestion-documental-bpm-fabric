package contract

import (
	"encoding/json"
	"errors"
	"fmt"

	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

// GestionDocumentalContract implementa las reglas del piloto experimental
// definido en el TFM. Aplica:
//   - SoD-1: el registrador no puede aprobar su propio documento (tabla 3)
//   - Secuencia obligatoria: no se publica sin APROBADO_LEGAL (tabla 3)
//   - HASH-1: validación de hash on-chain vs hash provisto (función verificarIntegridad)
//   - Control de acceso por atributo role= del certificado X.509 (ABAC)
type GestionDocumentalContract struct {
	contractapi.Contract
}

// ===========================================================================
// CREAR DOCUMENTO — solo role=registrador
// ===========================================================================
func (c *GestionDocumentalContract) CrearDocumento(
	ctx contractapi.TransactionContextInterface,
	docID, hash string, version int,
) error {
	_, actorID, err := requiereRol(ctx, RolRegistrador)
	if err != nil {
		return err
	}

	// UNI-1: no se permite registrar dos veces el mismo doc_id
	existe, err := c.docExiste(ctx, docID)
	if err != nil {
		return err
	}
	if existe {
		return fmt.Errorf("UNI-1 violado: el documento %s ya existe", docID)
	}

	ts, err := getTimestamp(ctx)
	if err != nil {
		return err
	}

	doc := Documento{
		DocID:         docID,
		DocumentHash:  hash,
		Version:       version,
		EstadoActual:  EstadoCreado,
		RegistradorID: actorID, // crítico para SoD-1
		Historial: []Evento{{
			EventType: EventoCreado,
			ActorID:   actorID,
			ActorRole: RolRegistrador,
			Hash:      hash,
			Version:   version,
			Timestamp: ts,
		}},
	}

	return c.guardar(ctx, &doc)
}

// ===========================================================================
// APROBAR REVISIÓN — solo role=revisor, NO puede ser el registrador (SoD-1)
// ===========================================================================
func (c *GestionDocumentalContract) AprobarRevision(
	ctx contractapi.TransactionContextInterface,
	docID string, aprobado bool, comentario string,
) error {
	_, actorID, err := requiereRol(ctx, RolRevisor)
	if err != nil {
		return err
	}

	doc, err := c.leer(ctx, docID)
	if err != nil {
		return err
	}

	// SoD-1: el revisor no puede ser el mismo que el registrador
	if actorID == doc.RegistradorID {
		return errors.New("SoD-1 violado: el registrador no puede aprobar su propio documento")
	}

	// Validación de secuencia: solo se puede revisar si está CREADO o RECHAZADO_REVISOR
	if doc.EstadoActual != EstadoCreado && doc.EstadoActual != EstadoRechazadoRevisor {
		return fmt.Errorf("estado inválido para revisión: %s", doc.EstadoActual)
	}

	ts, err := getTimestamp(ctx)
	if err != nil {
		return err
	}

	if aprobado {
		doc.EstadoActual = EstadoAprobadoRevisor
		doc.RevisorID = actorID
		doc.Historial = append(doc.Historial, Evento{
			EventType: EventoAprobadoRevisor,
			ActorID:   actorID,
			ActorRole: RolRevisor,
			Timestamp: ts,
			Comentario: comentario,
		})
	} else {
		doc.EstadoActual = EstadoRechazadoRevisor
		doc.Historial = append(doc.Historial, Evento{
			EventType: EventoRechazadoRevisor,
			ActorID:   actorID,
			ActorRole: RolRevisor,
			Timestamp: ts,
			Comentario: comentario,
		})
	}

	return c.guardar(ctx, doc)
}

// ===========================================================================
// APROBAR LEGAL — solo role=legal, requiere estado APROBADO_REVISOR
// ===========================================================================
func (c *GestionDocumentalContract) AprobarLegal(
	ctx contractapi.TransactionContextInterface,
	docID string, aprobado bool, comentario string,
) error {
	_, actorID, err := requiereRol(ctx, RolLegal)
	if err != nil {
		return err
	}

	doc, err := c.leer(ctx, docID)
	if err != nil {
		return err
	}

	// SoD-1 extendido: legal tampoco puede ser el registrador
	if actorID == doc.RegistradorID {
		return errors.New("SoD-1 violado: el registrador no puede aprobar legal de su propio documento")
	}

	if doc.EstadoActual != EstadoAprobadoRevisor && doc.EstadoActual != EstadoRechazadoLegal {
		return fmt.Errorf("estado inválido para revisión legal: %s (se requiere %s)", doc.EstadoActual, EstadoAprobadoRevisor)
	}

	ts, err := getTimestamp(ctx)
	if err != nil {
		return err
	}

	if aprobado {
		doc.EstadoActual = EstadoAprobadoLegal
		doc.LegalID = actorID
		doc.Historial = append(doc.Historial, Evento{
			EventType: EventoAprobadoLegal,
			ActorID:   actorID,
			ActorRole: RolLegal,
			Timestamp: ts,
			Comentario: comentario,
		})
	} else {
		doc.EstadoActual = EstadoRechazadoLegal
		doc.Historial = append(doc.Historial, Evento{
			EventType: EventoRechazadoLegal,
			ActorID:   actorID,
			ActorRole: RolLegal,
			Timestamp: ts,
			Comentario: comentario,
		})
	}

	return c.guardar(ctx, doc)
}

// ===========================================================================
// PUBLICAR DOCUMENTO — solo role=publicador, REQUIERE estado APROBADO_LEGAL
// (Regla SEQ-1 de la tabla 3: no se puede publicar sin revisión legal)
// ===========================================================================
func (c *GestionDocumentalContract) PublicarDocumento(
	ctx contractapi.TransactionContextInterface,
	docID string,
) error {
	_, actorID, err := requiereRol(ctx, RolPublicador)
	if err != nil {
		return err
	}

	doc, err := c.leer(ctx, docID)
	if err != nil {
		return err
	}

	// SEQ-1: no se publica sin aprobación legal previa
	if doc.EstadoActual != EstadoAprobadoLegal {
		return fmt.Errorf("SEQ-1 violado: no se puede publicar sin estado %s (estado actual: %s)",
			EstadoAprobadoLegal, doc.EstadoActual)
	}

	// SoD-1 extendido: el publicador tampoco puede ser el registrador
	if actorID == doc.RegistradorID {
		return errors.New("SoD-1 violado: el registrador no puede publicar su propio documento")
	}

	ts, err := getTimestamp(ctx)
	if err != nil {
		return err
	}

	doc.EstadoActual = EstadoPublicado
	doc.PublicadorID = actorID
	doc.Historial = append(doc.Historial, Evento{
		EventType: EventoPublicado,
		ActorID:   actorID,
		ActorRole: RolPublicador,
		Timestamp: ts,
	})

	return c.guardar(ctx, doc)
}

// ===========================================================================
// REGISTRAR REENVIADO — el registrador sube nueva versión tras rechazo
// ===========================================================================
func (c *GestionDocumentalContract) RegistrarReenviado(
	ctx contractapi.TransactionContextInterface,
	docID, nuevoHash string, nuevaVersion int,
) error {
	_, actorID, err := requiereRol(ctx, RolRegistrador)
	if err != nil {
		return err
	}

	doc, err := c.leer(ctx, docID)
	if err != nil {
		return err
	}

	// Solo se permite reenvío si fue rechazado por revisor o legal
	if doc.EstadoActual != EstadoRechazadoRevisor && doc.EstadoActual != EstadoRechazadoLegal {
		return fmt.Errorf("no se puede reenviar: estado actual %s", doc.EstadoActual)
	}

	// El reenvío debe hacerlo el registrador original (consistencia)
	if actorID != doc.RegistradorID {
		return errors.New("solo el registrador original puede reenviar el documento")
	}

	if nuevaVersion <= doc.Version {
		return fmt.Errorf("la nueva versión (%d) debe ser mayor que la actual (%d)", nuevaVersion, doc.Version)
	}

	ts, err := getTimestamp(ctx)
	if err != nil {
		return err
	}

	doc.DocumentHash = nuevoHash
	doc.Version = nuevaVersion
	doc.EstadoActual = EstadoCreado // vuelve a CREADO para reiniciar el flujo
	doc.Historial = append(doc.Historial, Evento{
		EventType: EventoReenviado,
		ActorID:   actorID,
		ActorRole: RolRegistrador,
		Hash:      nuevoHash,
		Version:   nuevaVersion,
		Timestamp: ts,
	})

	return c.guardar(ctx, doc)
}

// ===========================================================================
// ACTUALIZAR EVIDENCIA — registra cambio de hash sin cambiar de estado
// (por si la lógica BPM lo requiere para reconciliar off-chain)
// ===========================================================================
func (c *GestionDocumentalContract) ActualizarEvidencia(
	ctx contractapi.TransactionContextInterface,
	docID, nuevoHash string, version int,
) error {
	_, actorID, err := requiereRol(ctx, RolRegistrador)
	if err != nil {
		return err
	}

	doc, err := c.leer(ctx, docID)
	if err != nil {
		return err
	}

	if actorID != doc.RegistradorID {
		return errors.New("solo el registrador original puede actualizar la evidencia")
	}

	ts, err := getTimestamp(ctx)
	if err != nil {
		return err
	}

	doc.DocumentHash = nuevoHash
	doc.Version = version
	doc.Historial = append(doc.Historial, Evento{
		EventType: EventoEvidenciaUpdated,
		ActorID:   actorID,
		ActorRole: RolRegistrador,
		Hash:      nuevoHash,
		Version:   version,
		Timestamp: ts,
	})

	return c.guardar(ctx, doc)
}

// ===========================================================================
// CONSULTAR HISTORIAL — devuelve el documento completo con todo su historial.
// Accesible por auditor (y cualquier rol, ya que es solo lectura).
// ===========================================================================
func (c *GestionDocumentalContract) ConsultarHistorial(
	ctx contractapi.TransactionContextInterface,
	docID string,
) (*Documento, error) {
	return c.leer(ctx, docID)
}

// ===========================================================================
// VERIFICAR INTEGRIDAD — HASH-1: compara el hash on-chain contra uno externo.
// Devuelve true si coinciden, false si fueron alterados (escenario B del TFM).
// ===========================================================================
func (c *GestionDocumentalContract) VerificarIntegridad(
	ctx contractapi.TransactionContextInterface,
	docID, hashEsperado string,
) (*ResultadoVerificacion, error) {
	doc, err := c.leer(ctx, docID)
	if err != nil {
		return nil, err
	}

	coincide := doc.DocumentHash == hashEsperado
	return &ResultadoVerificacion{
		DocID:           docID,
		HashOnChain:     doc.DocumentHash,
		HashProvisto:    hashEsperado,
		Coincide:        coincide,
		EstadoActual:    doc.EstadoActual,
		VersionOnChain:  doc.Version,
	}, nil
}

// ResultadoVerificacion es el payload devuelto por VerificarIntegridad.
type ResultadoVerificacion struct {
	DocID          string `json:"doc_id"`
	HashOnChain    string `json:"hash_on_chain"`
	HashProvisto   string `json:"hash_provisto"`
	Coincide       bool   `json:"coincide"`
	EstadoActual   string `json:"estado_actual"`
	VersionOnChain int    `json:"version_on_chain"`
}

// ===========================================================================
// HELPERS INTERNOS
// ===========================================================================

func (c *GestionDocumentalContract) docExiste(
	ctx contractapi.TransactionContextInterface, docID string,
) (bool, error) {
	bytes, err := ctx.GetStub().GetState(docID)
	if err != nil {
		return false, fmt.Errorf("error leyendo world state: %w", err)
	}
	return bytes != nil, nil
}

func (c *GestionDocumentalContract) leer(
	ctx contractapi.TransactionContextInterface, docID string,
) (*Documento, error) {
	bytes, err := ctx.GetStub().GetState(docID)
	if err != nil {
		return nil, fmt.Errorf("error leyendo world state: %w", err)
	}
	if bytes == nil {
		return nil, fmt.Errorf("documento %s no encontrado", docID)
	}
	var doc Documento
	if err := json.Unmarshal(bytes, &doc); err != nil {
		return nil, fmt.Errorf("error deserializando documento: %w", err)
	}
	return &doc, nil
}

func (c *GestionDocumentalContract) guardar(
	ctx contractapi.TransactionContextInterface, doc *Documento,
) error {
	bytes, err := json.Marshal(doc)
	if err != nil {
		return fmt.Errorf("error serializando documento: %w", err)
	}
	if err := ctx.GetStub().PutState(doc.DocID, bytes); err != nil {
		return fmt.Errorf("error escribiendo world state: %w", err)
	}
	return nil
}
