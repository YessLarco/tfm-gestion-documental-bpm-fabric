# Chaincode `gestiondocumental` — TFM BPM + Hyperledger Fabric

Contrato inteligente en Go que implementa las reglas del piloto experimental
definidas en el documento de metodología (Fase 2, Actividad 2.2).

## Reglas implementadas (tabla 3)

| Regla | Descripción | Implementación |
|---|---|---|
| **SoD-1** | El registrador no puede aprobar su propio documento | Validación en `AprobarRevision`, `AprobarLegal`, `PublicarDocumento` |
| **SEQ-1** | No se publica sin aprobación legal previa | Validación de `EstadoActual == APROBADO_LEGAL` en `PublicarDocumento` |
| **UNI-1** | No se permite duplicar `doc_id` | Validación en `CrearDocumento` |
| **HASH-1** | Hash on-chain inmutable, verificable | Función `VerificarIntegridad` |
| **ABAC** | Control de acceso por atributo `role=` del certificado X.509 | Función `requiereRol` lee `cid.GetAttributeValue("role")` |

## Estructura

```
gestiondocumental/
├── go.mod
├── main.go                  # entrypoint del chaincode
└── contract/
    ├── modelo.go            # estructuras Documento, Evento, constantes
    ├── helpers.go           # extracción de rol/ID del cert X.509
    └── contrato.go          # funciones del contrato
```

## Funciones expuestas

| Función | Rol requerido | Estado previo válido |
|---|---|---|
| `CrearDocumento(docID, hash, version)` | registrador | (ninguno) |
| `AprobarRevision(docID, aprobado, comentario)` | revisor | CREADO, RECHAZADO_REVISOR |
| `AprobarLegal(docID, aprobado, comentario)` | legal | APROBADO_REVISOR, RECHAZADO_LEGAL |
| `PublicarDocumento(docID)` | publicador | APROBADO_LEGAL |
| `RegistrarReenviado(docID, nuevoHash, nuevaVersion)` | registrador (el original) | RECHAZADO_REVISOR, RECHAZADO_LEGAL |
| `ActualizarEvidencia(docID, nuevoHash, version)` | registrador (el original) | (cualquiera) |
| `ConsultarHistorial(docID)` | cualquiera (solo lectura) | — |
| `VerificarIntegridad(docID, hashEsperado)` | cualquiera (solo lectura) | — |

## Despliegue en la test-network

Ejecutar desde `~/bpm-fabric/fabric/fabric-samples/test-network`:

```bash
./network.sh deployCC \
  -ccn gestiondocumental \
  -ccp ~/proyecto-bpm-fabric/chaincode-fabric/gestiondocumental \
  -ccl go \
  -c mychannel
```
