package main

import (
	"log"

	"github.com/hyperledger/fabric-contract-api-go/contractapi"
	"github.com/tfm/gestiondocumental/contract"
)

func main() {
	cc, err := contractapi.NewChaincode(&contract.GestionDocumentalContract{})
	if err != nil {
		log.Panicf("error creando chaincode: %v", err)
	}
	if err := cc.Start(); err != nil {
		log.Panicf("error arrancando chaincode: %v", err)
	}
}
